import UIKit
import PlaygroundSupport

// OOP Approach

// Single Super-class - Tight Coupling of different behaviors like draw() and area()
class Shape {
    var origin: CGPoint
    var size: CGSize
    var color: UIColor
    
    init(origin: CGPoint, size: CGSize, color: UIColor) {
        self.origin = origin
        self.size = size
        self.color = color
    }
    
    func draw(on context: CGContext) {
        fatalError("overide \(#function)") // No Definition Possible here.
    }
    
    func area() -> CGFloat {
        return size.width * size.height
    }
    
    // We could have acheived static dispatch here. But restricted to using dynamic dispatch.
    func printArea() {
        print(area().rounded())
    }
}

// We are restricted to only using reference types here. (classes)

class Circle: Shape {
    
    var radius: CGFloat {
        return size.width / 2
    }
    
    init(origin: CGPoint, radius: CGFloat, color: UIColor) {
        let size = CGSize(width: radius*2, height: radius*2)
        super.init(origin: origin, size: size, color: color)
    }
    
    override func draw(on context: CGContext) {
        let rect = CGRect(x: origin.x-radius, y: origin.y-radius, width: (radius * 2), height: (radius * 2))
        context.setFillColor(color.cgColor)
        context.addEllipse(in: rect)
        context.drawPath(using: .fillStroke)
    }
    
    override func area() -> CGFloat {
        return .pi * radius * radius
    }
}

// CGRect built-in types exists which we are unable to use here.

class Rectange: Shape {
    
    override func area() -> CGFloat {
        return size.width * size.height
    }
    
    override func draw(on context: CGContext) {
        let rectangle = CGRect(x: origin.x, y: origin.y, width: size.width, height: size.height)
        context.setFillColor(color.cgColor)
        context.addRect(rectangle)
        context.drawPath(using: .fillStroke)
        
    }
}

////////////////////////////////////////////////////////////////////////////////

class RenderView: UIView {
    
    var shapes: [Shape] = [] {
        didSet {
            setNeedsDisplay()
        }
    }
    
    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }
        
        shapes.forEach {
            $0.draw(on: context)
        }
    }
}

let renderView = RenderView(frame: CGRect(origin: .zero, size: CGSize(width: 400, height: 400)))

var shapes: [Shape] = []

// We are using types that are reference based - class.

let circle = Circle(origin: CGPoint(x: 100, y: 100), radius: 50, color: UIColor.blue)
let rectangle = Rectange(origin:  CGPoint(x: 200, y: 200), size: CGSize(width: 50, height: 50), color: UIColor.blue)
shapes.append(contentsOf: [circle,rectangle])

shapes.forEach {
    $0.printArea()
}

// Render
renderView.shapes = shapes
PlaygroundPage.current.liveView = renderView

