import UIKit
import AVFoundation

extension Date {
    func timeString(timeFormat: TimeFormat) -> String {
        let dateFormatter = DateFormatter()
        if timeFormat == .TWELVLE {
             dateFormatter.dateFormat = "hh:mm a"
        }
        else {
            dateFormatter.dateFormat = "HH:mm"
        }
        return dateFormatter.string(from: self)
    }
}

enum TimeFormat {
    case TWELVLE
    case TWENTY_FOUR
}

class Alexa {
    let wakeWord: String
    var timeFormat: TimeFormat
  
    init(wakeWord: String, timeFormat: TimeFormat) {
        self.wakeWord = wakeWord
        self.timeFormat = timeFormat
    }

    func whatsTheTime() {
        let timeString = Date().timeString(timeFormat: timeFormat)
        speak(text: timeString)
        display(text: timeString)
    }

    private func speak(text: String) {
        let speechSynthesizer = AVSpeechSynthesizer()
        let speechUtterance = AVSpeechUtterance(string: text)
        speechSynthesizer.speak(speechUtterance)
    }
    
    private func display(text: String) {
        print(text)
    }
}

class ConferenceRoom {
    let name: String
    let virtualAssistant: Alexa // Tight Coupling with Alexa type. We cant configure other types that show same behavior.

    init(name: String, virtualAssistant: Alexa) {
        self.name = name
        self.virtualAssistant = virtualAssistant
    }

    func tellMeTime() {
        print("\(virtualAssistant.wakeWord)...What's is the time\n")
        virtualAssistant.whatsTheTime()
    }
}

let room = ConferenceRoom(name: "1W-2", virtualAssistant: Alexa(wakeWord: "Alexa", timeFormat: .TWELVLE))
room.tellMeTime()
