import UIKit
import PlaygroundSupport
import CoreGraphics

// Protocol Oriented approach

protocol Shape {
    var origin: CGPoint { get }
    var size: CGSize { get }
    func area() -> CGFloat
}

protocol Drawable {
    var color: UIColor { get }
    func draw(on context: CGContext)
}

// Protocol Extensiosn to Provide Default Implementaiton. This is a customization point as-in Circle refines this API as per its needs.
// Common Implementations for Protocol conforming types can come here.
extension Shape {
    func area() -> CGFloat {
        return size.width * size.height
    }
    // This would be available to all types that conform to Shape. Its static dispatch and not a customization point.
    func printArea() {
        print(area().rounded())
    }
}

// Compostion of Different protocols instead of single inheritance.

struct Circle: Shape, Drawable {
    let origin: CGPoint
    let size: CGSize
    let color: UIColor
    var radius: CGFloat {
        return size.width / 2
    }
    
    init(origin: CGPoint, radius: CGFloat, color: UIColor) {
        self.origin = origin
        self.size = CGSize(width: radius*2, height: radius*2)
        self.color = color
    }
    
    func draw(on context: CGContext) {
        let rect = CGRect(x: origin.x-radius, y: origin.y-radius, width: (radius * 2), height: (radius * 2))
        context.setFillColor(color.cgColor)
        context.addEllipse(in: rect)
        context.drawPath(using: .fillStroke)
    }
    
    func area() -> CGFloat {
        return .pi * radius * radius
    }
}

// We are using Value Types
struct Rectangle: Shape, Drawable {
    let origin: CGPoint
    let size: CGSize
    let color: UIColor
    
    func draw(on context: CGContext) {
        let rectangle = CGRect(x: origin.x, y: origin.y, width: size.width, height: size.height)
        context.setFillColor(color.cgColor)
        context.addRect(rectangle)
        context.drawPath(using: .fillStroke)
    }
}

////////////////////////////////////////////////////////////////////////////////

class RenderView: UIView {
    
    var items: [Drawable] = [] {
        didSet {
            setNeedsDisplay()
        }
    }
    
    override func draw(_ rect: CGRect) {
        guard let context = UIGraphicsGetCurrentContext() else {
            return
        }
        
        items.forEach {
            $0.draw(on: context) // Dynamic Dispatch is used to decide which implementaiton to call at runtime. (Polymorphism)
        }
    }
}

let renderView = RenderView(frame: CGRect(origin: .zero, size: CGSize(width: 400, height: 400)))
var objects: [Shape & Drawable] = [] // Protocol Compostion example.

let circle: Shape & Drawable = Circle(origin: CGPoint(x: 100, y: 100), radius: 50, color: UIColor.blue)
let rectangle: Shape & Drawable = Rectangle(origin: CGPoint(x: 200, y: 200), size: CGSize(width: 50, height: 50), color: UIColor.blue)
objects.append(contentsOf: [circle, rectangle])

objects.forEach {
    $0.printArea()
}

// Render
renderView.items = objects
PlaygroundPage.current.liveView = renderView


