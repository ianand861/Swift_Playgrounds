import UIKit
import AVFoundation

extension Date {
    func timeString(timeFormat: TimeFormat) -> String {
        let dateFormatter = DateFormatter()
        if timeFormat == .TWELVLE {
             dateFormatter.dateFormat = "hh:mm a"
        }
        else {
            dateFormatter.dateFormat = "HH:mm"
        }
        return dateFormatter.string(from: self)
    }
}

enum TimeFormat {
    case TWELVLE
    case TWENTY_FOUR
}

protocol VirtualAssistant {
    var wakeWord: String {get} // Property Requirements requiring to be gettable.
    var timeFormat: TimeFormat {get set} // Property Requirements requiring to be settable and gettable.
    func whatsTheTime() // Method Requirements
}

extension VirtualAssistant {
    func speak(text: String) {
        let speechSynthesizer = AVSpeechSynthesizer()
        let speechUtterance = AVSpeechUtterance(string: text)
        speechSynthesizer.speak(speechUtterance)
    }
    func display(text: String) {
        print(text)
    }
}

struct Alexa: VirtualAssistant {
    let wakeWord: String = "Alexa"
    var timeFormat: TimeFormat
    
    func whatsTheTime() {
        let timeString = Date().timeString(timeFormat: timeFormat)
        display(text: timeString)
        speak(text: timeString)
    }
}

struct GoogleAssistant: VirtualAssistant {
    let wakeCall = "Hey Google"
    var timeFormat: TimeFormat
    
    var wakeWord: String {
        get {
            return wakeCall
        }
    }
    
    func whatsTheTime() {
        let timeString = Date().timeString(timeFormat: timeFormat)
        display(text: timeString)
        speak(text: timeString)
    }
}

class ConferenceRoom {
    let name: String
    let virtualAssistant: VirtualAssistant // Protocols are types. They can be used as full-fledged types in our code. Existential type

    init(name: String, virtualAssistant: VirtualAssistant) {
        self.name = name
        self.virtualAssistant = virtualAssistant
    }

    func time() {
        print("\(virtualAssistant.wakeWord)...What's is the time\n")
        virtualAssistant.whatsTheTime()
    }
}

let alexa = Alexa(timeFormat: .TWELVLE)
let google = GoogleAssistant(timeFormat: .TWENTY_FOUR)

let room = ConferenceRoom(name: "1W-2", virtualAssistant: alexa)
room.time()

