import UIKit

//---------------- Seperation and Logical Grouping based on Functionality.

//Example - 1
struct Person {
    let first: String
    let last: String
}

extension Person {
    init(dictionary: [String: String]) {
        self.first = dictionary["first"] ?? "John"
        self.last = dictionary["last"] ?? "Doe"
    }
}

let person: Person = Person(first: "John", last: "Archer")

class FieldViewController: UIViewController {
    
}

// Example - 2
private typealias PrivateMethods_SET_ENTRY_POINT = FieldViewController
private extension PrivateMethods_SET_ENTRY_POINT {

   // All Private Methods go here
}

typealias LocationHistory = FieldViewController
extension LocationHistory {

   // LocationHistory Methods go here.
}
