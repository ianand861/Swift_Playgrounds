import UIKit

//-------------- Protocol Conformance and Retroactive Modelling

// This shows logical grouping as per protocol conformance.

class DetailViewController: UIViewController {
    
}

extension DetailViewController:UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return UITableViewCell()
    }
}

// Retroactive Modelling

import CoreGraphics

struct Circle {
  var origin: CGPoint
  var radius: CGFloat
}

let circle = Circle(origin: .zero, radius: 10)
let rect = CGRect(origin: .zero, size: CGSize(width: 300, height: 200))

// Create an array of circles and rectangles
// Compute the sum of all the areas

protocol Geometry {
  var origin: CGPoint { get set }
  func area() -> CGFloat
}

extension Circle: Geometry {
  func area() -> CGFloat {
    return .pi * radius * radius
  }
}

extension CGRect: Geometry {
  func area() -> CGFloat {
    return size.width * size.height
  }
}

let shapes: [Geometry] = [circle, rect]

shapes.forEach {
    print($0.area().rounded())
}
