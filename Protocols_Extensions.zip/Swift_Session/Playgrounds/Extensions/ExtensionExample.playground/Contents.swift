import UIKit


// Extensions Basics

// Custom Type

struct Airplane
{
    let altitude: Double
}

extension Airplane {
    
    // Add Instance Methods
    func altitudeInMeters() -> Double {
        return (altitude / 3.28).rounded()
    }
    
    func printAltitudeInMeters() {
        print("Planes altitide is \(altitudeInMeters()) meters")
    }
}

let plane = Airplane(altitude: 5000)
plane.printAltitudeInMeters()

// Existing Type

extension Int {
    
    // Add Computed Properties
    var square : Int {
        return self*self
    }
    
    func cube() -> Int {
        return self*self*self
    }
    
    mutating func increment(value: Int) {
        self = self + value
    }
}

let number: Int = 5
print("Square of \(number) is \(number.square)")


