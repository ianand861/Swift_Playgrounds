import UIKit

// Namespaced Constants and Nested Types
// We can add static constants and subtypes to extensions

extension Int {
    enum Kind {
        case negative, zero, positive
    }
    var kind: Kind {
        switch self {
        case 0:
            return .zero
        case let x where x > 0:
            return .positive
        default:
            return .negative
        }
    }
}

print(5.kind)

extension UserDefaults
{
    struct Keys
    {
        static let useSync  = "use_sync"
        static let lastSync = "last_sync"
    }
}

UserDefaults.standard.set(true, forKey: UserDefaults.Keys.useSync)
